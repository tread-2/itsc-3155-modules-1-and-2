word1 = input("Enter a string: ")
word2 = input("Enter another string: ")

if word2.endswith(word1):
    print("True")
else:
    print("False")