cubed = int(input("Enter an integer greater than 1: "))

for i in range(cubed + 1):
    print(f"The cubed number for {i} is {i**3}")